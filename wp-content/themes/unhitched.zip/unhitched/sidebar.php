<div class="sidebar">
    <h4>There's more...</h4>    
    <?php wp_get_archives('type=postbypost&limit=15'); ?>
</div>