quoteRotator({optional title}, {delay in seconds, optional}, {fade-in duration in seconds, optional}, {fade-out duration in seconds, optional});
e.g.1: <?php echo quoteRotator(); ?>
e.g.2: <?php echo quoteRotator("Testimonials", 8, 4, 2); ?>