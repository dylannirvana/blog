
<div id="myCarousel" class="carousel slide hidden-xs">
   
    <section class="carousel-inner">
                                    
        <div class="active item"><h1> "Life begins at the end of your comfort zone."</h1>
    <p>Neale Donald Walsch </p></div>
        
        
        
        <div class="item"><img src="<?php bloginfo('template_directory'); ?>/images/carousel/acrilycs_workshop.jpg"></div>
        <div class="item"><img src="<?php bloginfo('template_directory'); ?>/images/carousel/quicksketch_workshop.jpg"></div>

    </section> <!-- carousel-inner -->
    
    <!-- <a href="#myCarousel" class="left carousel-control" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
    <a href="#myCarousel" class="right carousel-control" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a> -->
    
</div> <!-- myCarousel -->
